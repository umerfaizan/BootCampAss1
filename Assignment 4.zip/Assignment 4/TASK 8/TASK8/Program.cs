﻿using System.Data;
using Microsoft.Data.SqlClient;
using System.Data.SqlClient;

String connectionString = "Server=DESKTOP-GN41MNF\\SQLEXPRESS;DataBase=5085_DB;Trusted_Connection=True;Encrypt=False";
using (SqlConnection connection = new SqlConnection(connectionString))
{
    /*  using (SqlCommand command = new SqlCommand("AddNewStudent", connection))
      {
          command.CommandType = CommandType.StoredProcedure;
          command.Parameters.AddWithValue("@FirstName", "Mahjabeen");
          command.Parameters.AddWithValue("@LastName", "Manzoor");
          command.Parameters.AddWithValue("@Age", 30);
          command.Parameters.AddWithValue("@CourseID", 101);
          connection.Open();
          command.ExecuteNonQuery();
          connection.Close();
      }*/
    /* using(SqlCommand command = new SqlCommand("UpdateStudentAge", connection))
     {
         command.CommandType=CommandType.StoredProcedure;
         command.Parameters.AddWithValue("@Age", 30);
         command.Parameters.AddWithValue("@StudentID", 5);
         connection.Open();
         command.ExecuteNonQuery();
         connection.Close();
     }*/
    /* using(SqlCommand command=new SqlCommand("DeleteStudent", connection))
     {
         command.CommandType = CommandType.StoredProcedure;
         command.Parameters.AddWithValue("@StudentID", 2);
         connection.Open (); 
         command.ExecuteNonQuery();
         connection.Close();
     }*/
    using (SqlCommand command = new SqlCommand("Allstudents", connection))
    {
        command.CommandType = CommandType.StoredProcedure;
        connection.Open();
        SqlDataReader reader = command.ExecuteReader();
        while (reader.Read())
        {
            Console.WriteLine($"StudentID: {reader["StudentID"]}, FirstName: {reader["FirstName"]},LastName: {reader["LastName"]}, Age: {reader["Age"]}, CourseID: {reader["CourseID"]}");
        }
        connection.Close();

    }

}
