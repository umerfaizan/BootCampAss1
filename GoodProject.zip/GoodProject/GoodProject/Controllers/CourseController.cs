﻿//Adding extensions at first needed as per used cases in code as Microsofr.Data.SqlClient for accesing SQL Client
using Microsoft.AspNetCore.Mvc;
using System.Data;
using Microsoft.Data.SqlClient;
using GoodProject.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Cors;
using System.Collections.Generic;

namespace WeekendProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")] //ROUTING
    public class CourseController : Controller
    {
        private readonly DbContext _dbContext;
        public CourseController(IConfiguration configuration)
        {
            _dbContext = new DbContext(configuration); //ACCESSING AND CONFURING DBCONTEXT(SERVER)
        }

        //CODE FOR LIST OF COURSES

        [HttpGet]
        public IActionResult GetAllCourses()
        {

            List<Course> Courses = new List<Course>();                                                  // List of Course class which will save all course attributes
            using (SqlCommand command = new SqlCommand("AllCourses", _dbContext.Connection))            // making SQL Command for accessing procedure in SQL data base
            {
                command.CommandType = CommandType.StoredProcedure;
                _dbContext.Connection.Open();                                                           // Opening connection for fetching data    
                SqlDataReader reader = command.ExecuteReader();                                         // SQL Reader fetching data 
                while (reader.Read())
                {
                    Course Cou = new Course();

                    Cou.CourseID = (int)reader["CourseID"];
                    Cou.CourseName = reader["CourseName"].ToString();
                    Courses.Add(Cou);
                }

                _dbContext.Connection.Close();
            }
            return Ok(Courses);                                                                         // Returning All fetched data in form of class Courses
        }

        //CODE FOR ADDING NEW COURSE

        [HttpPost]                                                                                      // for posting some thing inside tables
        public IActionResult AddNewCourse(Course NewCourse)
        {


            using (SqlCommand command = new SqlCommand("AddNewCourse", _dbContext.Connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CourseName", NewCourse.CourseName);                   // Storing Course Name and Course ID taken from User
                _dbContext.Connection.Open();
                command.ExecuteNonQuery();

                _dbContext.Connection.Close();
            }
            return Ok();
        }

        //CODE FOR CHANGING COURSE NAME 

        [HttpPut]                                                                                       //For Updating Something inside Tables
        public IActionResult UpdateCourseName(Course NewCourse)
        {


            using (SqlCommand command = new SqlCommand("UpdateCourseName", _dbContext.Connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CourseName", NewCourse.CourseName);                   //For Updating the name as given by User
                command.Parameters.AddWithValue("@CourseID", NewCourse.CourseID);                       // For updating at the ID given by user
                _dbContext.Connection.Open();
                command.ExecuteNonQuery();

                _dbContext.Connection.Close();
            }
            return Ok();
        }

        //CPURSE FOR DELETIG SPECIFIC COURSE

        [HttpDelete]
        public IActionResult DeleteCourse(Course NewCourse)
        {


            using (SqlCommand command = new SqlCommand("DeleteCourse", _dbContext.Connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CourseID", NewCourse.CourseID);                       //For Deleteing from the CourseID as given by user
                _dbContext.Connection.Open();
                command.ExecuteNonQuery();

                _dbContext.Connection.Close();
            }
            return Ok();
        }

    }
}
