﻿namespace GoodProject.Models
{
    public class CourseWithNoOfRegistrations
    {
        public int CourseID { get; set; }
        public int NoOfStudents { get; set; }
    }
}
