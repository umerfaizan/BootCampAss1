﻿
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

Console.WriteLine("\t\t\tchecking Perfect number\n\n\n");   //printing Task heading
Console.Write("Plesae write your number \t"); //Asks user to write the number user Wants to cehck
int Number = int.Parse(Console.ReadLine()); //asigns value to variable Number
int x = 0; //initiating variable x as zero as we want to will add all divisors in this
int half = Number / 2;
for(int i = 1; i <= half; i++)// initiating for loop from 1 to half of Number as divisor can be max half of the number
{
    if(Number % i == 0) //checking if the i is divisor of Number
    {
        x = x + i;   // adding to x for final check
    }



}
if (Number == x) // now if x(addition of divisors) is equal to Number, number is Perfect
{
    Console.WriteLine("\n\nYour number is perfect ");

}
else
{
    Console.WriteLine("\n\nYour Number is not perfect");
}