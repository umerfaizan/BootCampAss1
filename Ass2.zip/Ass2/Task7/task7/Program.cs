﻿Console.WriteLine("\t\t\tSorting an Array task\n\n\n");
Console.Write("Please Enter Length of array you want :\t");
int Length = int.Parse(Console.ReadLine()); 
int[] Array= new int[Length];
int x = 1;
for (int i = 0; i < Length; i++)
{
    Console.Write("\nPlease write number on "+x+" Index of Array\t");
    Array[i]=int.Parse(Console.ReadLine());
    x++;
}
int[] NewArray=new int[Length];
Console.WriteLine("\n\nYour Array was : \n\n");
for (int i = 0;i < Length;i++)
{
    Console.Write("" + Array[i] + "\t");
}
x = 0;
int Smallest;
int Largest = Array[0];
for(int i = 0;i < Length; i++)
{

    if (Largest == Array[i] || Largest < Array[i])
    {
        Largest = Array[i];
    } 
}
for(int i = 0; i < Length; i++)
{
     Smallest = Array[0];
    for (int j = 0; j < Length; j++)
    {
        if ( Smallest >= Array[j])
        {
            Smallest = Array[j];
            x = j;
        }
        
    }
    NewArray[i] = Smallest;
    Array[x] = Largest;
}
Console.WriteLine("\n\n Your sorted array is \n\n");
for(int i =0; i < Length; i++)
{
    Console.Write("" + NewArray[i] + "\t");
}