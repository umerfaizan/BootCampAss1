﻿Console.WriteLine("\t\t\tSubSequence tasks\n\n\n");
string String1 = "ABCDGH";
string String2 = "AEDFHR";
int Length = String1.Length;
int x = 0;
List<char> Chars=new List<char>();
for(int i = 0; i < Length; i++)
{

    for(int j=x; j < Length; j++)
    {
        if (String1[i] == String2[j])
        {
            x = j;
            Chars.Add(String1[i]);
            break;
        }
    }
    
}
int Listlength = Chars.Count;
string Common = "";
for(int i = 0;i < Listlength; i++)
{
    Common=Common + Chars[i];
}
Console.WriteLine("\n\n Your common String is \t"+Common);
