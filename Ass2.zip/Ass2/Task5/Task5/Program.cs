﻿Console.Write("\t\t\tTriangle Stars task\n\n\n"); //prints task Heading
Console.Write("Please write No of Rows\t"); //Asks user to write No of Rows
int Rows=int.Parse(Console.ReadLine()); //assigning that value to Variable rows
for(int i = 1; i <= Rows; i++) // starts for loop from 1 to rows for completing rows number
{
    for(int j = i; j <= Rows - 1; j++) //for loop for printing spaces as for first line spaces are n-1 and decreasing every row
    {
        Console.Write(" ");
    }
    for(int k = 1; k < i * 2; k++) // for printing stars, as for every line there are two stars increasing
    {
        Console.Write("*");
    }
    Console.Write("\n");// for moving to next row after execution of both for loops as stated above

}