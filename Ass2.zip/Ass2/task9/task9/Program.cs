﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("\t\t\tNumber Right triangle\n\n\n"); //task Heading
Console.Write("Please Enter Number Of Rows\t"); //Asks user to write number
int Rows=int.Parse(Console.ReadLine()); //assigns value to variable Rows
for (int i = 1;i <= Rows;i++) //For Loop from 1 to Number of Rows(for going to next row
{
    for (int j = 1; j <= i; j++) //For loop for printing  numbers
    {
        Console.Write(j);
    }
    Console.Write("\n");
}
