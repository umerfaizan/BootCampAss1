﻿Console.WriteLine("\t\t\tRight Angle triangle task\n\n\n");    //prints Task Heading
Console.Write("Please write the number of Rows\t"); //Asks user to write no of rows user wants
int rows=int.Parse(Console.ReadLine());  //assigns no of rows written by user to rows variable
for(int i = 1; i <= rows; i++) //starts loop from 1 to no of rows
{
    for(int j= 1;j <= i; j++) //starts another loop from 1 to value of i(to print no of * in a row)
    {
        Console.Write("*\t");
    }
    Console.Write("\n"); //cursor Moves to next line(next row)
}
