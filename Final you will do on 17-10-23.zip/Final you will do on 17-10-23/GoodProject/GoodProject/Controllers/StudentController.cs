﻿
//Adding extensions at first needed as per used cases in code as Microsofr.Data.SqlClient for accesing SQL Client
using Microsoft.AspNetCore.Mvc;
using System.Data;
using Microsoft.Data.SqlClient;
using GoodProject.Models;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;

namespace GoodProject.Controllers
{

    [ApiController]
    [Route("api/[controller]")] //Giving Route Map
    public class StudentController : ControllerBase
    {
        private readonly DbContext _dbContext;

        public StudentController(IConfiguration configuration)
        {
            _dbContext = new DbContext(configuration); //Connecting DBContext cs file to configuration
        }
        //CODE FOR Getting ALL Student List



        [HttpGet] //used for getting response from server
        public IActionResult GetAllStudents()
        {

            List<Student> Studentss = new List<Student>();
            using (SqlCommand command = new SqlCommand("Allstudents", _dbContext.Connection)) //command for accesing specific command from server
            {
                command.CommandType = CommandType.StoredProcedure;
                _dbContext.Connection.Open(); //Opening Connection 
                SqlDataReader reader = command.ExecuteReader(); //For Reading data out of command in server
                while (reader.Read())
                {
                    Student emp = new Student();
                    emp.StudentID = (int)reader["StudentID"];
                    emp.FirstName = reader["FirstName"].ToString();
                    emp.LastName = reader["lastName"].ToString();
                    emp.Age = (int)reader["Age"];
                    emp.CourseID = (int)reader["CourseID"];

                    Studentss.Add(emp);
                }

                _dbContext.Connection.Close();
            }
            return Ok(Studentss);
        }

        //CODE FOR ADDING NEW STUDENT 

        [HttpPost("add")] //used for Posting something on server
        public IActionResult AddNewStudent(Student Student)
        {



            using (SqlCommand command = new SqlCommand("AddNewStudent", _dbContext.Connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@FirstName", Student.FirstName); //fetching data from user end 
                command.Parameters.AddWithValue("@LastName", Student.LastName); //fetching data from user end
                command.Parameters.AddWithValue("@Age", Student.Age);//fetching data from user end
                command.Parameters.AddWithValue("@CourseID", Student.CourseID);//fetching data from user end
                _dbContext.Connection.Open();
                command.ExecuteNonQuery();
                _dbContext.Connection.Close();
                return Ok();
            }
        }



        //CODE FOR DELETING STUDENT DATA

        [HttpDelete("Delete/{StudentID}")]                                                          // written inside {} showing that its an input
        public IActionResult DeleteStudent(int StudentID)
        {



            using (SqlCommand command = new SqlCommand("DeleteStudent", _dbContext.Connection))     // Acessing DeleteStudent Procedure From SQL
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@StudentID", StudentID);
                _dbContext.Connection.Open();                                                       //Opening Conection to the server
                command.ExecuteNonQuery();                                                           //Executing Command but without getting response
                _dbContext.Connection.Close();                                                       //Closing Connections
                return Ok();
            }
        }

        //CODE FOR UPADTING STUDENT DATA

        [HttpPut]
        public IActionResult UpdateStudentAge([FromForm] int Age, [FromForm] int StudentID)         // Acessing UpdateStudentAge Procedure From SQL        
        {



            using (SqlCommand command = new SqlCommand("UpdateStudentAge", _dbContext.Connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Age", Age);
                command.Parameters.AddWithValue("@StudentID", StudentID);

                _dbContext.Connection.Open();                                                       //Opening Conection to the server
                command.ExecuteNonQuery();                                                          //Executing Command but without getting response
                _dbContext.Connection.Close();                                                      //Closing Connection
                return Ok();
            }


        }

        //CODE FOR FETCHING STUDENT DATA FOR STUDENTS OLDER THEN SPECIFIC AGE

        [HttpGet("Age")] //ROUTING
        public IActionResult GetStudentsOlderThenAge()                                          // Acessing GetStudentsOlderThenAge Procedure From SQL
        {

            List<Student> Studentss = new List<Student>();
            using (SqlCommand command = new SqlCommand("GetStudentsOlderThenAge", _dbContext.Connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Age", 20);
                _dbContext.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Student emp = new Student();
                    emp.StudentID = (int)reader["StudentID"];
                    emp.FirstName = reader["FirstName"].ToString();
                    emp.LastName = reader["lastName"].ToString();
                    emp.Age = (int)reader["Age"];
                    emp.CourseID = (int)reader["CourseID"];

                    Studentss.Add(emp);
                }

                _dbContext.Connection.Close();
            }
            return Ok(Studentss);
        }

        // CODE FOR GETTING STUDENTS DATA FROM SPECIFIC COURSE

        [HttpGet("Course/{CourseID}")]                                                      //Route saying /course will come after  original route and CourseID is input
        public IActionResult GetStudentsInSpecificCourse(int CourseID)                      // Acessing GetStudentsInSpecificCourse Procedure From SQL
        {

            List<Student> Studentss = new List<Student>();
            using (SqlCommand command = new SqlCommand("GetStudentsInSpecificCourse", _dbContext.Connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CourseId", CourseID);
                _dbContext.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())                                                       //Feteching all students from that specific GetStudentsInSpecificCourse in SQl
                {
                    Student emp = new Student();
                    emp.StudentID = (int)reader["StudentID"];
                    emp.FirstName = reader["FirstName"].ToString();
                    emp.LastName = reader["lastName"].ToString();
                    emp.Age = (int)reader["Age"];
                    emp.CourseID = (int)reader["CourseID"];

                    Studentss.Add(emp);
                }

                _dbContext.Connection.Close();                                              //Closing Connection after complete execution of procedure
            }
            return Ok(Studentss);                                                           //Returning Data in form of Class Student
        }

        //CODE FOR GETTING MOS POPULAR COURSE AND NO OF STUDENTS IN IT


        [HttpGet("Course/Popular")]
        public IActionResult MostPopularCourse()                                            // Acessing MostPopularCourse Procedure From SQL
        {

            CourseWithNoOfRegistrations one = new CourseWithNoOfRegistrations();
            using (SqlCommand command = new SqlCommand("MostPopularCourse", _dbContext.Connection))
            {
                command.CommandType = CommandType.StoredProcedure;

                _dbContext.Connection.Open();                                               //Opening Connection
                SqlDataReader reader = command.ExecuteReader();                             //Reader is fetching data from that procedure
                while (reader.Read())
                {
                    one.CourseID = (int)reader["CourseID"];
                    one.NoOfStudents = (int)reader["REPEAT_TIME"];
                }
                _dbContext.Connection.Close();                                              //Closing connection
            }
            return Ok(one);                                                                 //Returning Data in form of class CourseWithNoOfRegistrations
        }
    }

}





