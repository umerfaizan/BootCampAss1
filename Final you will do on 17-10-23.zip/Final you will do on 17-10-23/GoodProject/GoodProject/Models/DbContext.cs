﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using GoodProject.Models;

namespace GoodProject.Models
{
    public class DbContext
    {
        public SqlConnection Connection { get; set; }
        public DbContext(IConfiguration configuration)
        {
            Connection = new SqlConnection(configuration.GetConnectionString("connectionString"));
        }
    }
}
