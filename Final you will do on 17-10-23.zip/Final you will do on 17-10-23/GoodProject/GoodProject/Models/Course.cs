﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using Microsoft.Data.SqlClient;
using GoodProject.Models;





namespace GoodProject.Models
{
    public class Course
    {
        public int CourseID { get; set; }
        public string? CourseName { get; set; }
    }
}
