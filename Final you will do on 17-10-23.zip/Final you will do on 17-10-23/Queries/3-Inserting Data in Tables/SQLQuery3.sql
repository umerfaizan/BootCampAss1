INSERT INTO Courses 
VALUES
('MATHS'),
('BIOLOGY'),
('CHEMISTRY'),
('PHYSICS'),
('ENGLISH');
INSERT INTO Students
VALUES
('Umer','Faizan',24,1),
('Rana','Yasir',29,1),
('Aima','Ameen',14,2),
('Yasmeen','Manzoor',19,2),
('Shagufta','Rana',17,2),
('Aneeka','Yousaf',18,2),
('Mirza','Ans',26,3),
('Chachu','Iftkihar',29,3),
('Babar','Azam',26,4),
('RIZI','Boi',21,4);

SELECT * FROM Courses;
SELECT * FROM Students;


