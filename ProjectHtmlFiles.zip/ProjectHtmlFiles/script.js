function addStudent() {
    var FirstName = $('#FirstName').val();
	var LastName = $('#LastName').val();
    var Age = $('#Age').val();
    var CourseID = $('#CourseID').val();

    var Student = {
        firstName: FirstName,
		lastName: LastName,
        age: Age,
        courseID: CourseID
    };

    $.ajax({
        url: 'https://localhost:44390/api/Student/add',
        type: 'POST',
        data: JSON.stringify(Student),
        contentType: 'application/json',
        success: function() {
            // Clear form
            $('#StudentForm')[0].reset();
            // Update Student List
            fetchStudents();
        }
    });
}
function deleteStudent() {
    var StudentID = $('#DStudentID').val();
	
    $.ajax({
	url: 'https://localhost:44390/api/Student/Delete',
        type: 'PUT',
        data: StudentID,
        contentType: 'application/json',
        success: function() {
            // Clear form
            $('#DeleteForm')[0].reset();
            // Update Student List
            fetchStudents();
        }
    });
}





function fetchStudents() {
    $.ajax({
        url: 'https://localhost:44390/api/Student',
        type: 'GET',
        success: function(data) {
            $('#StudentList').empty();
            data.forEach(function(Student) {
                $('#StudentList').append('<li class="list-group-item">' + Student.studentID+', ' + Student.firstName + ', ' + Student.lastName + ', ' + Student.age+ ', ' +Student.courseID + '</li>');
            });
        }
    });
}
$(document).ready(function() {
    fetchStudents();
	});