﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using Microsoft.Data.SqlClient;
using WebApplication1.Models;
using WeekendProject.Models;




namespace WeekendProject.Models
{
    public class Course
    {
        public int CourseID { get; set; }
        public string ? CourseName { get; set; }
    }
}
