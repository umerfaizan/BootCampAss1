﻿using Microsoft.Data.SqlClient;

namespace WebApplication1.Models
{
    public class DbContext
    {
        public SqlConnection Connection { get; set; }
        public DbContext(IConfiguration configuration)
        {
            Connection = new SqlConnection(configuration.GetConnectionString("connectionString"));
        }
    }
}
