//Adding extensions at first needed as per used cases in code as Microsofr.Data.SqlClient for accesing SQL Client
using Microsoft.AspNetCore.Mvc;
using System.Data;
using Microsoft.Data.SqlClient;
using WebApplication1.Models;
using WeekendProject.Models;

namespace WebApplication1.Controllers
{

    [ApiController]
    [Route("api/[controller]")] //Giving Route Map
    public class StudentController : ControllerBase
    {
        private readonly DbContext _dbContext; 

        public StudentController(IConfiguration configuration)
        {
            _dbContext = new DbContext(configuration); //Connecting DBContext cs file to configuration
        }
//CODE FOR Getting ALL Student List



        [HttpGet] //used for getting response from server
        public IActionResult GetAllStudents()
        {

            List<Student> Studentss = new List<Student>();
            using (SqlCommand command = new SqlCommand("Allstudents", _dbContext.Connection)) //command for accesing specific command from server
            {
                command.CommandType = CommandType.StoredProcedure;
                _dbContext.Connection.Open(); //Opening Connection 
                SqlDataReader reader = command.ExecuteReader(); //For Reading data out of command in server
                while (reader.Read())
                {
                    Student emp = new Student();
                    emp.StudentID = (int)reader["StudentID"];
                    emp.FirstName = reader["FirstName"].ToString();
                    emp.LastName = reader["lastName"].ToString();
                    emp.Age = (int)reader["Age"];
                    emp.CourseID = (int)reader["CourseID"];

                    Studentss.Add(emp);
                }

                _dbContext.Connection.Close();
             }
            return Ok(Studentss);
        }

//CODE FOR ADDING NEW STUDENT 

        [HttpPost("add")] //used for Posting something on server
        public IActionResult AddNewStudent(Student Student)
        {



            using (SqlCommand command = new SqlCommand("AddNewStudent", _dbContext.Connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@FirstName", Student.FirstName); //fetching data from user end 
                command.Parameters.AddWithValue("@LastName", Student.LastName); //fetching data from user end
                command.Parameters.AddWithValue("@Age", Student.Age);//fetching data from user end
                command.Parameters.AddWithValue("@CourseID", Student.CourseID);//fetching data from user end
                _dbContext.Connection.Open(); 
                command.ExecuteNonQuery();
                _dbContext.Connection.Close();
                return Ok();
            }
        }



//CODE FOR DELETING STUDENT DATA

        [HttpDelete("Delete/{StudentID}")]
        public IActionResult DeleteStudent(int StudentID)
        {



            using (SqlCommand command = new SqlCommand("DeleteStudent", _dbContext.Connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@StudentID", StudentID);
                _dbContext.Connection.Open();
                command.ExecuteNonQuery();
                _dbContext.Connection.Close();
                return Ok();
            }
        }

//CODE FOR UPADTING STUDENT DATA

        [HttpPut]
        public IActionResult UpdateStudentAge([FromForm] int Age, [FromForm] int StudentID)
        {



            using (SqlCommand command = new SqlCommand("UpdateStudentAge", _dbContext.Connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Age", Age);
                command.Parameters.AddWithValue("@StudentID", StudentID);

                _dbContext.Connection.Open();
                command.ExecuteNonQuery();
                _dbContext.Connection.Close();
                return Ok();
            }


        }

//CODE FOR FETCHING STUDENT DATA FOR STUDENTS OLDER THEN SPECIFIC AGE

        [HttpGet("Age")] //ROUTING
        public IActionResult GetStudentsOlderThenAge()
        {

            List<Student> Studentss = new List<Student>();
            using (SqlCommand command = new SqlCommand("GetStudentsOlderThenAge", _dbContext.Connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Age",20);
                _dbContext.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Student emp = new Student();
                    emp.StudentID = (int)reader["StudentID"];
                    emp.FirstName = reader["FirstName"].ToString();
                    emp.LastName = reader["lastName"].ToString();
                    emp.Age = (int)reader["Age"];
                    emp.CourseID = (int)reader["CourseID"];

                    Studentss.Add(emp);
                }

                _dbContext.Connection.Close();
            }
            return Ok(Studentss);
        }

// CODE FOR GETTING STUDENTS DATA FROM SPECIFIC COURSE

        [HttpGet("Course/{CourseID}")]
        public IActionResult GetStudentsInSpecificCourse(int CourseID)
        {

            List<Student> Studentss = new List<Student>();
            using (SqlCommand command = new SqlCommand("GetStudentsInSpecificCourse", _dbContext.Connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CourseId", CourseID);
                _dbContext.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Student emp = new Student();
                    emp.StudentID = (int)reader["StudentID"];
                    emp.FirstName = reader["FirstName"].ToString();
                    emp.LastName = reader["lastName"].ToString();
                    emp.Age = (int)reader["Age"];
                    emp.CourseID = (int)reader["CourseID"];

                    Studentss.Add(emp);
                }

                _dbContext.Connection.Close();
            }
            return Ok(Studentss);
        }

//CODE FOR GETTING MOS POPULAR COURSE AND NO OF STUDENTS IN IT


        [HttpGet("Course/Popular")]
        public IActionResult MostPopularCourse()
        {

            CourseWithNoOfRegistrations one = new CourseWithNoOfRegistrations();
            using (SqlCommand command = new SqlCommand("MostPopularCourse", _dbContext.Connection))
            {    
                command.CommandType = CommandType.StoredProcedure;
               
                _dbContext.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    one.CourseID = (int)reader["CourseID"];
                    one.NoOfStudents = (int)reader["REPEAT_TIME"];
                }
                _dbContext.Connection.Close();
            }
            return Ok(one);
        }
    }

}




