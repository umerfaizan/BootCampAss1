﻿//Adding extensions at first needed as per used cases in code as Microsofr.Data.SqlClient for accesing SQL Client
using Microsoft.AspNetCore.Mvc;
using System.Data;
using Microsoft.Data.SqlClient;
using WebApplication1.Models;
using WeekendProject.Models;


namespace WeekendProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")] //ROUTING
    public class CourseController : Controller
    {
        private readonly DbContext _dbContext;
        public CourseController(IConfiguration configuration)
        {
            _dbContext = new DbContext(configuration); //ACCESSING AND CONFURING DBCONTEXT(SERVER)
        }

//CODE FOR LIST OF COURSES

        [HttpGet]
        public IActionResult GetAllCourses()
        {

            List<Course> Courses = new List<Course>();
            using (SqlCommand command = new SqlCommand("AllCourses", _dbContext.Connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                _dbContext.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Course Cou = new Course();
                    
                    Cou.CourseID = (int)reader["CourseID"];
                    Cou.CourseName = reader["CourseName"].ToString();
                    Courses.Add(Cou);
                }

                _dbContext.Connection.Close();
            }
            return Ok(Courses);
        }
        
//CODE FOR ADDING NEW COURSE

        [HttpPost]
        public IActionResult AddNewCourse(Course NewCourse)
        {

           
            using (SqlCommand command = new SqlCommand("AddNewCourse", _dbContext.Connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CourseName", NewCourse.CourseName);
                command.Parameters.AddWithValue("@CourseID", NewCourse.CourseID);
                _dbContext.Connection.Open();
                command.ExecuteNonQuery();

                _dbContext.Connection.Close();
            }
            return Ok();
        }

//CODE FOR CHANGING COURSE NAME 

        [HttpPut]
        public IActionResult UpdateCourseName(Course NewCourse)
        {


            using (SqlCommand command = new SqlCommand("UpdateCourseName", _dbContext.Connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CourseName", NewCourse.CourseName);
                command.Parameters.AddWithValue("@CourseID", NewCourse.CourseID);
                _dbContext.Connection.Open();
                command.ExecuteNonQuery();

                _dbContext.Connection.Close();
            }
            return Ok();
        }

//CPURSE FOR DELETIG SPECIFIC COURSE

        [HttpDelete]
        public IActionResult DeleteCourse(Course NewCourse)
        {


            using (SqlCommand command = new SqlCommand("DeleteCourse", _dbContext.Connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CourseID", NewCourse.CourseID);
                _dbContext.Connection.Open();
                command.ExecuteNonQuery();

                _dbContext.Connection.Close();
            }
            return Ok();
        }
       
    }
}
