SELECT * FROM Students;
GO
--ADD NEW STUDENT
CREATE PROCEDURE AddNewStudent
		@FirstName VARCHAR(50),
		@LastName VARCHAR(50),
		@Age INT,
		@CourseID INT
AS
BEGIN 
INSERT INTO Students(FirstName,LastName,Age,CourseID)
VALUES(@FirstName,@LastName,@Age,@CourseID)
END
GO
--UPDATE STUDENT AGE
CREATE PROCEDURE UpdateStudentAge
		@Age INT,
		@StudentID INT
AS
BEGIN
UPDATE Students
SET Age=@Age
Where Students.StudentID=@StudentID;
END
GO

--DELETE STUDENTS DATA

CREATE PROCEDURE DeleteStudent
		@StudentID INT
AS
BEGIN
DELETE FROM Students
WHERE Students.StudentID=@StudentID
END
GO

--TO LIST ALL STUDENTS
CREATE PROCEDURE Allstudents
AS
BEGIN
SELECT * FROM Students
END
GO

--TO LIST ALL Courses
CREATE PROCEDURE AllCourses
AS
BEGIN
SELECT * FROM Courses
END
GO
--TO Add New Course
CREATE PROCEDURE AddNewCourse
		@CourseName VARCHAR(50),
		@CourseID INT
AS
BEGIN 
INSERT INTO Courses(CourseID,CourseName)
VALUES(@CourseID,@CourseName)
END
GO
--TO Update course Name
CREATE PROCEDURE UpdateCourseName
		@CourseID INT,
		@CourseName VARCHAR(50)
AS
BEGIN 
UPDATE Courses
SET CourseName=@CourseName
WHERE CourseID=@CourseID
END
GO
--TO Delete course
CREATE PROCEDURE DeleteCourse
		@CourseID INT
AS
BEGIN
DELETE FROM Courses
WHERE CourseID=@CourseID
END
GO
--TO LIST All students Greater then a cetain age
CREATE PROCEDURE GetStudentsOlderThenAge
		@Age INT
AS
BEGIN
SELECT Students.StudentID,Students.FirstName,Students.LastName,Students.Age,Students.CourseID
FROM Students
WHERE Students.Age>@Age
END
GO
--TO LIST ALL students in Specific Course
CREATE PROCEDURE GetStudentsInSpecificCourse
		@CourseId INT
AS
BEGIN
SELECT * FROM Students
Where CourseID=@CourseId
END
GO


--TO LIST Most Popular Course

CREATE PROCEDURE MostPopularCourse
AS 
BEGIn
SELECT TOP 1 Students.CourseID,COUNT(Students.CourseID) AS REPEAT_TIME
FROM Students
GROUP BY Students.CourseID
ORDER BY Students.CourseID
END
GO