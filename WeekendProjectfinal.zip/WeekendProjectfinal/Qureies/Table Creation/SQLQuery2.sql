  
CREATE TABLE Students(
StudentID INT PRIMARY KEY,
FirstName VARCHAR(50),
LastName VARCHAR(50),
AGE INT,
CourseID INT,
);
GO
CREATE TABLE Courses(
CourseID INT PRIMARY KEY,
CourseName VARCHAR(50)
);
GO
ALTER TABLE Students 
ADD CONSTRAINT fk_CourseID
FOREIGN KEY (CourseID) REFERENCES Courses(CourseID);
GO