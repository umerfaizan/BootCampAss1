INSERT INTO Courses 
VALUES
(100,'MATHS'),
(101,'BIOLOGY'),
(102,'CHEMISTRY'),
(103,'PHYSICS'),
(104,'ENGLISH');
INSERT INTO Students
VALUES
('Umer','Faizan',24,100),
('Rana','Yasir',29,100),
('Aima','Ameen',14,101),
('Yasmeen','Manzoor',19,101),
('Shagufta','Rana',17,102),
('Aneeka','Yousaf',18,102),
('Mirza','Ans',26,103),
('Chachu','Iftkihar',29,103),
('Babar','Azam',26,104),
('RIZI','Boi',21,104);
